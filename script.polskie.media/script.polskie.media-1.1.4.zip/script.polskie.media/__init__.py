# -*- coding: utf-8 -*-
"""
App name
~~~~~~

:copyright: (c) 2014 by Marek Nowiński.
:license: GNU GPL Version 3, see LICENSE for more details.
"""